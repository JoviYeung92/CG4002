/*
----------------------------------------------------------------------------------
--	(c) Rajesh C Panicker, NUS,
--  Description : Self-checking testbench for AXI Stream Coprocessor (HLS) implementing the sum of 4 numbers
--	License terms :
--	You are free to use this code as long as you
--		(i) DO NOT post a modified version of this on any public repository;
--		(ii) use it only for educational purposes;
--		(iii) accept the responsibility to ensure that your implementation does not violate any intellectual property of any entity.
--		(iv) accept that the program is provided "as is" without warranty of any kind or assurance regarding its suitability for any particular purpose;
--		(v) send an email to rajesh.panicker@ieee.org briefly mentioning its use (except when used for the course EE4218 at the National University of Singapore);
--		(vi) retain this notice in this file or any files derived from this.
----------------------------------------------------------------------------------
*/

#include <stdio.h>
#include "hls_stream.h"

/***************** AXIS with TLAST structure declaration *********************/

struct AXIS_wLAST
{
    int data;
    bool last;
};

/***************** Coprocessor function declaration *********************/

void mlpHLS(hls::stream<AXIS_wLAST> &S_AXIS, hls::stream<AXIS_wLAST> &M_AXIS);

/***************** Macros *********************/
#define NUMBER_OF_INPUT_WORDS 86 // length of an input vector
#define NUMBER_OF_OUTPUT_WORDS 9  // length of an input vector
#define NUMBER_OF_TEST_VECTORS 1  // number of such test vectors (cases)

/************************** Variable Definitions *****************************/
int test_result_expected_memory[NUMBER_OF_TEST_VECTORS * NUMBER_OF_OUTPUT_WORDS];
int result_memory[NUMBER_OF_TEST_VECTORS * NUMBER_OF_OUTPUT_WORDS];

typedef union {
  int i;
  float f;
 } u;

/*****************************************************************************
* Main function
******************************************************************************/
int main()
{
    int word_cnt, test_case_cnt = 0;
    float in[86] = {-0.02, -0.14, -0.09, 0.0, -182.49, -51.33, -278.07, 1.19, 0.89, 0.69, 1.4889929, 26.73, 12.55, 0.0, 0.85833335, 0.09916667, 0.079166666, 0.99086124, -17.360834, -8.616667, -107.82917, 0.3917234, 0.34001124, 0.26831132, 0.33477947, 50.604717, 17.078943, 94.600044, 0.014826, 0.007413, 0.014826, 0.013542273, 1.045233, 1.378818, 7.93191, 1.2733333, 140.55, 0.006666667, 0.039193254, 0.0225, 0.055391088, 12.205292, 2.22178, 5.8438864, 0.85833335, 0.17536412, 0.14229281, 0.99086124, 17.360834, 8.616667, 107.82917, 0.16408707, 0.09136686, 0.06822125, 0.17236482, 15.329134, 5.034958, 31.703697, 0.21738762, 0.045886487, 0.043213297, 0.24788569, 1.880776, 2.268032, 26.6377, 0.058367666, 0.044458292, 0.050193176, 0.029233461, 1.2591707, 2.4355237, 22.354404, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 2.618669, 0.7230112, 0.5462981, 2.9666936, -0.8749678, 0.38604727, 1.7593076};
    AXIS_wLAST read_output, write_input;
    hls::stream<AXIS_wLAST> S_AXIS;
    hls::stream<AXIS_wLAST> M_AXIS;

    /************** Run a software version of the hardware function to validate results ************/
    // instead of hard-coding the results in test_result_expected_memory

    /******************** Input to Coprocessor : Transmit the Data Stream ***********************/

    printf(" Transmitting Data for test case %d ... \r\n", test_case_cnt);

    for (int i = 0; i < 86; i++)
    {
    	u input;
    	input.f = in[i];

    	write_input.data = input.i;
		write_input.last = 0;
		if (i == 86)
		{
			write_input.last = 1;
			// S_AXIS_TLAST is asserted for the last word.
			// Actually, doesn't matter since we are not making using of S_AXIS_TLAST.
		}
		S_AXIS.write(write_input); // insert one word into the stream

    }

    /* Transmission Complete */

    /********************* Call the hardware function (invoke the co-processor / ip) ***************/

    mlpHLS(S_AXIS, M_AXIS);

    /******************** Output from Coprocessor : Receive the Data Stream ***********************/

    printf(" Receiving data for test case %d ... \r\n", test_case_cnt);

    for (word_cnt = 0; word_cnt < NUMBER_OF_OUTPUT_WORDS; word_cnt++)
    {

        read_output = M_AXIS.read(); // extract one word from the stream
        result_memory[word_cnt + test_case_cnt * NUMBER_OF_OUTPUT_WORDS] = read_output.data;
    }
    for (int i = 0; i < 4; i++)
    {
    	 u out;
    	out.i = result_memory[i];
        printf("%f\n",out.f);
    }

    /* Reception Complete */
}

/************************** Checking correctness of results *****************************/

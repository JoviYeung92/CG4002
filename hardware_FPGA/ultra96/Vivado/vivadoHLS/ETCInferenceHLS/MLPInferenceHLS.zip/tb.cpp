/*
----------------------------------------------------------------------------------
--	(c) Rajesh C Panicker, NUS,
--  Description : Self-checking testbench for AXI Stream Coprocessor (HLS) implementing the sum of 4 numbers
--	License terms :
--	You are free to use this code as long as you
--		(i) DO NOT post a modified version of this on any public repository;
--		(ii) use it only for educational purposes;
--		(iii) accept the responsibility to ensure that your implementation does not violate any intellectual property of any entity.
--		(iv) accept that the program is provided "as is" without warranty of any kind or assurance regarding its suitability for any particular purpose;
--		(v) send an email to rajesh.panicker@ieee.org briefly mentioning its use (except when used for the course EE4218 at the National University of Singapore);
--		(vi) retain this notice in this file or any files derived from this.
----------------------------------------------------------------------------------
*/

#include <stdio.h>
#include "hls_stream.h"

/***************** AXIS with TLAST structure declaration *********************/

struct AXIS_wLAST
{
    int data;
    bool last;
};

/***************** Coprocessor function declaration *********************/

void mlpHLS(hls::stream<AXIS_wLAST> &S_AXIS, hls::stream<AXIS_wLAST> &M_AXIS);

/***************** Macros *********************/
#define NUMBER_OF_INPUT_WORDS 86 // length of an input vector
#define NUMBER_OF_OUTPUT_WORDS 8  // length of an input vector
#define NUMBER_OF_TEST_VECTORS 1  // number of such test vectors (cases)

/************************** Variable Definitions *****************************/
int test_result_expected_memory[NUMBER_OF_TEST_VECTORS * NUMBER_OF_OUTPUT_WORDS];
int result_memory[NUMBER_OF_TEST_VECTORS * NUMBER_OF_OUTPUT_WORDS];

typedef union {
  int i;
  float f;
 } u;

/*****************************************************************************
* Main function
******************************************************************************/
int main()
{
    int word_cnt, test_case_cnt = 0;
    float in[86] = {-1.1, -0.98, -0.72, 0.7034913,
                    -248.28, -1.06, -304.64, 0.15,
                    0.45, 0.74, 1.4705101, 251.98,
                    2.98, -250.78, -0.6641667, -0.30833334,
                    -0.13083333, 1.0191717, 25.781666, 1.52,
                    -278.8525, 0.32709473, 0.36108246, 0.5425627,
                    0.21526493, 163.32704, 1.0004416, 16.582827,
                    0.244629, 0.318759, 0.400302, 0.2644251,
                    106.89546, 0.266868, 25.471067, 1.6116667,
                    406.47583, 0.04950449, 0.03166667, 0.04069705,
                    0.03348237, 0.55333334, 0.03166667, 0.56648344,
                    0.6641667, 0.30833334, 0.31233537, 1.0191717,
                    80.89244, 1.52, 278.8525, 0.14168707,
                    0.11751395, 0.13378398, 0.14016065, 37.35364,
                    0.3746697, 26.334982, 0.16000147, 0.07055475,
                    0.08977462, 0.26603726, 29.716553, 0.36818868,
                    76.21862, 0.02723923, 0.03006232, 0.06681803,
                    0.03418012, 23.554428, 0.18925038, 1.4951711,
                    0.0, 0.0, 1.0, 0.0,
                    1.0, 0.0, 0.0, 2.8513887,
                    1.2392353, 1.061053, 2.9744313, 0.5258642,
                    2.3715322, 3.0036242};

    AXIS_wLAST read_output, write_input;
    hls::stream<AXIS_wLAST> S_AXIS;
    hls::stream<AXIS_wLAST> M_AXIS;

    /************** Run a software version of the hardware function to validate results ************/
    // instead of hard-coding the results in test_result_expected_memory

    /******************** Input to Coprocessor : Transmit the Data Stream ***********************/

    printf(" Transmitting Data for test case %d ... \r\n", test_case_cnt);

    for (int i = 0; i < 86; i++)
    {
    	u input;
    	input.f = in[i];

    	write_input.data = input.i;
		write_input.last = 0;
		if (i == 86)
		{
			write_input.last = 1;
			// S_AXIS_TLAST is asserted for the last word.
			// Actually, doesn't matter since we are not making using of S_AXIS_TLAST.
		}
		S_AXIS.write(write_input); // insert one word into the stream

    }

    /* Transmission Complete */

    /********************* Call the hardware function (invoke the co-processor / ip) ***************/

    mlpHLS(S_AXIS, M_AXIS);

    /******************** Output from Coprocessor : Receive the Data Stream ***********************/

    printf(" Receiving data for test case %d ... \r\n", test_case_cnt);

    for (word_cnt = 0; word_cnt < 8; word_cnt++)
    {

        read_output = M_AXIS.read(); // extract one word from the stream
        result_memory[word_cnt + test_case_cnt * 8] = read_output.data;
    }
    for (int i = 0; i < 8; i++)
    {
		int out = result_memory[i];
        printf("%d\n",out);
    }

    /* Reception Complete */
}

/************************** Checking correctness of results *****************************/

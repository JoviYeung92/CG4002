/*
----------------------------------------------------------------------------------
--	(c) Rajesh C Panicker, NUS,
--  Description : Self-checking testbench for AXI Stream Coprocessor (HLS) implementing the sum of 4 numbers
--	License terms :
--	You are free to use this code as long as you
--		(i) DO NOT post a modified version of this on any public repository;
--		(ii) use it only for educational purposes;
--		(iii) accept the responsibility to ensure that your implementation does not violate any intellectual property of any entity.
--		(iv) accept that the program is provided "as is" without warranty of any kind or assurance regarding its suitability for any particular purpose;
--		(v) send an email to rajesh.panicker@ieee.org briefly mentioning its use (except when used for the course EE4218 at the National University of Singapore);
--		(vi) retain this notice in this file or any files derived from this.
----------------------------------------------------------------------------------
*/

#include <stdio.h>
#include "hls_stream.h"

/***************** AXIS with TLAST structure declaration *********************/

struct AXIS_wLAST
{
    int data;
    bool last;
};

/***************** Coprocessor function declaration *********************/

void knnHLS(hls::stream<AXIS_wLAST> &S_AXIS, hls::stream<AXIS_wLAST> &M_AXIS);

/***************** Macros *********************/
#define NUMBER_OF_INPUT_WORDS 768 // length of an input vector
#define NUMBER_OF_OUTPUT_WORDS 4  // length of an input vector
#define NUMBER_OF_TEST_VECTORS 1  // number of such test vectors (cases)

/************************** Variable Definitions *****************************/
int zzTrain[256][3] = {
    {22, 57, 69},
    {12, 55, 52},
    {3, 45, 37},
    {17, 30, 31},
    {27, 17, 26},
    {34, 16, 21},
    {43, 15, 18},
    {52, 6, 16},
    {62, 3, 16},
    {68, 9, 17},
    {71, 12, 15},
    {71, 13, 13},
    {65, 10, 13},
    {60, 5, 13},
    {52, 1, 16},
    {43, 7, 14},
    {29, 16, 15},
    {16, 22, 24},
    {4, 36, 41},
    {17, 41, 54},
    {21, 44, 58},
    {13, 45, 48},
    {2, 37, 33},
    {19, 23, 22},
    {27, 17, 15},
    {29, 14, 9},
    {27, 13, 6},
    {26, 15, 10},
    {26, 18, 14},
    {24, 19, 18},
    {16, 20, 20},
    {14, 21, 28},
    {13, 22, 36},
    {9, 27, 39},
    {4, 28, 38},
    {7, 24, 41},
    {10, 26, 44},
    {6, 35, 39},
    {1, 37, 39},
    {6, 36, 43},
    {7, 30, 51},
    {9, 29, 50},
    {15, 30, 50},
    {14, 23, 57},
    {17, 28, 58},
    {22, 33, 54},
    {23, 37, 51},
    {18, 33, 52},
    {16, 30, 51},
    {18, 31, 49},
    {19, 33, 48},
    {19, 34, 48},
    {18, 33, 48},
    {19, 32, 47},
    {21, 36, 46},
    {23, 35, 45},
    {23, 33, 43},
    {25, 33, 44},
    {26, 34, 45},
    {29, 36, 44},
    {29, 34, 44},
    {26, 31, 44},
    {22, 26, 47},
    {19, 24, 50},
    {17, 23, 52},
    {12, 20, 56},
    {9, 18, 58},
    {5, 16, 58},
    {5, 17, 54},
    {9, 19, 44},
    {16, 22, 37},
    {28, 20, 32},
    {47, 28, 30},
    {66, 48, 34},
    {81, 61, 39},
    {84, 54, 39},
    {67, 39, 26},
    {51, 33, 20},
    {40, 25, 19},
    {31, 23, 17},
    {22, 25, 19},
    {15, 26, 23},
    {9, 24, 27},
    {1, 20, 34},
    {6, 13, 45},
    {8, 11, 56},
    {6, 13, 65},
    {6, 12, 64},
    {1, 14, 64},
    {2, 15, 57},
    {6, 14, 46},
    {10, 16, 37},
    {16, 14, 32},
    {33, 20, 27},
    {58, 32, 34},
    {68, 58, 41},
    {70, 58, 44},
    {65, 52, 52},
    {60, 50, 42},
    {42, 42, 40},
    {31, 42, 39},
    {22, 33, 45},
    {12, 24, 48},
    {6, 30, 52},
    {1, 41, 54},
    {3, 38, 56},
    {8, 29, 54},
    {4, 34, 49},
    {0, 41, 56},
    {2, 33, 45},
    {4, 25, 50},
    {0, 23, 41},
    {3, 25, 43},
    {4, 25, 42},
    {7, 22, 40},
    {11, 20, 39},
    {12, 21, 40},
    {14, 24, 40},
    {14, 27, 39},
    {18, 25, 39},
    {20, 25, 38},
    {21, 24, 36},
    {21, 24, 36},
    {21, 25, 33},
    {20, 22, 29},
    {19, 21, 27},
    {19, 20, 23},
    {21, 16, 22},
    {23, 16, 21},
    {25, 17, 21},
    {24, 17, 20},
    {27, 16, 19},
    {31, 14, 18},
    {36, 8, 17},
    {41, 5, 16},
    {48, 0, 19},
    {52, 3, 19},
    {58, 8, 22},
    {58, 7, 22},
    {52, 2, 21},
    {47, 5, 22},
    {42, 3, 22},
    {28, 12, 25},
    {12, 30, 37},
    {5, 36, 55},
    {24, 49, 77},
    {25, 58, 73},
    {5, 51, 51},
    {11, 36, 38},
    {21, 19, 28},
    {30, 13, 21},
    {36, 15, 16},
    {46, 14, 16},
    {54, 10, 16},
    {63, 4, 17},
    {65, 2, 18},
    {64, 2, 18},
    {64, 1, 16},
    {62, 3, 16},
    {57, 6, 17},
    {52, 7, 17},
    {44, 11, 17},
    {31, 17, 17},
    {15, 26, 24},
    {5, 35, 39},
    {27, 43, 62},
    {34, 54, 65},
    {14, 51, 48},
    {7, 37, 27},
    {23, 19, 15},
    {32, 3, 4},
    {36, 2, 1},
    {37, 5, 0},
    {34, 8, 4},
    {29, 10, 12},
    {22, 15, 21},
    {14, 25, 31},
    {8, 27, 35},
    {8, 27, 39},
    {10, 29, 39},
    {11, 30, 36},
    {13, 28, 36},
    {12, 27, 36},
    {5, 32, 38},
    {1, 35, 41},
    {4, 30, 45},
    {10, 31, 44},
    {11, 34, 43},
    {12, 30, 45},
    {9, 23, 51},
    {14, 24, 48},
    {20, 33, 45},
    {24, 39, 44},
    {23, 28, 46},
    {24, 23, 46},
    {28, 28, 44},
    {37, 39, 46},
    {37, 37, 49},
    {38, 35, 52},
    {40, 36, 51},
    {41, 38, 50},
    {39, 38, 49},
    {36, 34, 46},
    {34, 34, 45},
    {32, 32, 46},
    {32, 34, 44},
    {29, 34, 41},
    {26, 32, 40},
    {21, 27, 41},
    {9, 20, 47},
    {0, 17, 51},
    {5, 19, 56},
    {13, 27, 55},
    {9, 20, 46},
    {8, 15, 36},
    {19, 16, 32},
    {33, 16, 23},
    {47, 15, 18},
    {62, 13, 19},
    {75, 19, 26},
    {85, 32, 30},
    {86, 35, 29},
    {77, 31, 27},
    {61, 22, 27},
    {56, 18, 30},
    {47, 18, 30},
    {39, 20, 30},
    {26, 17, 35},
    {14, 12, 42},
    {0, 9, 50},
    {10, 10, 57},
    {8, 15, 61},
    {2, 21, 60},
    {1, 21, 57},
    {7, 21, 52},
    {11, 16, 43},
    {16, 14, 33},
    {24, 14, 26},
    {37, 13, 21},
    {52, 16, 19},
    {67, 28, 23},
    {71, 32, 30},
    {69, 30, 36},
    {69, 34, 46},
    {64, 38, 46},
    {56, 35, 48},
    {43, 30, 51},
    {34, 26, 48},
    {30, 32, 52},
    {28, 36, 57},
    {24, 40, 57},
    {19, 34, 58},
    {13, 34, 57},
    {7, 41, 48},
    {13, 41, 47},
    {11, 38, 46},
};
int test_result_expected_memory[NUMBER_OF_TEST_VECTORS * NUMBER_OF_OUTPUT_WORDS]; // 4 outputs *2
int result_memory[NUMBER_OF_TEST_VECTORS * NUMBER_OF_OUTPUT_WORDS];               // same size as test_result_expected_memory

/*****************************************************************************
* Main function
******************************************************************************/
int main()
{
    int word_cnt, test_case_cnt = 0;
    AXIS_wLAST read_output, write_input;
    hls::stream<AXIS_wLAST> S_AXIS;
    hls::stream<AXIS_wLAST> M_AXIS;

    /************** Run a software version of the hardware function to validate results ************/
    // instead of hard-coding the results in test_result_expected_memory

    /******************** Input to Coprocessor : Transmit the Data Stream ***********************/

    printf(" Transmitting Data for test case %d ... \r\n", test_case_cnt);

    for (int i = 0; i < 256; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            write_input.data = zzTrain[i][j];
            write_input.last = 0;
            if (i == 255 && j == 2)
            {
                write_input.last = 1;
                // S_AXIS_TLAST is asserted for the last word.
                // Actually, doesn't matter since we are not making using of S_AXIS_TLAST.
            }
            S_AXIS.write(write_input); // insert one word into the stream
        }
    }

    /* Transmission Complete */

    /********************* Call the hardware function (invoke the co-processor / ip) ***************/

    knnHLS(S_AXIS, M_AXIS);

    /******************** Output from Coprocessor : Receive the Data Stream ***********************/

    printf(" Receiving data for test case %d ... \r\n", test_case_cnt);

    for (word_cnt = 0; word_cnt < NUMBER_OF_OUTPUT_WORDS; word_cnt++)
    {

        read_output = M_AXIS.read(); // extract one word from the stream
        result_memory[word_cnt + test_case_cnt * NUMBER_OF_OUTPUT_WORDS] = read_output.data;
    }
    for (int i = 0; i < 3; i++)
    {
        printf("%d\n", result_memory[i]);
    }

    /* Reception Complete */
}

/************************** Checking correctness of results *****************************/
